// إعدادات (قابلة للربط مع Supabase من لوحة الأدمن)
const settings = {
  facebook: "https://facebook.com/yourpage"
};
document.getElementById("fbLink").href = settings.facebook;

// بيانات تجريبية
const mods = [
  {title:"Dragons World", type:"featured", rating:5},
  {title:"More Weapons", type:"free", rating:4},
  {title:"Realistic Shaders", type:"paid", rating:5}
];

function createCard(mod){
  const d=document.createElement("div");
  d.className="card";
  d.innerHTML=`<h3>${mod.title}</h3>
  <div class="rating">⭐ ${mod.rating}/5</div>
  ${mod.type==="paid" ? "<button>شراء الآن</button>" : "<button>تحميل</button>"}`;
  return d;
}

mods.forEach(m=>{
  if(m.type==="featured") featuredContainer.appendChild(createCard(m));
  if(m.type==="free") freeContainer.appendChild(createCard(m));
  if(m.type==="paid") paidContainer.appendChild(createCard(m));
});
